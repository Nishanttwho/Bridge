import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Signals received from TradingView
export const signals = pgTable("signals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  type: varchar("type", { length: 10 }).notNull(), // 'buy' or 'sell'
  symbol: varchar("symbol", { length: 20 }).notNull(),
  entryPrice: decimal("entry_price", { precision: 20, scale: 8 }).notNull(),
  stopLoss: decimal("stop_loss", { precision: 20, scale: 8 }),
  takeProfit: decimal("take_profit", { precision: 20, scale: 8 }),
  status: varchar("status", { length: 20 }).notNull().default('pending'), // pending, sent, executed, failed
  rawPayload: text("raw_payload"),
});

// Trades executed in MT5
export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  signalId: varchar("signal_id").references(() => signals.id),
  executionTime: timestamp("execution_time").notNull().defaultNow(),
  status: varchar("status", { length: 20 }).notNull(), // open, closed, failed
  mt5OrderId: varchar("mt5_order_id", { length: 50 }),
  profitLoss: decimal("profit_loss", { precision: 20, scale: 8 }),
  closeTime: timestamp("close_time"),
});

// MT5 Configuration
export const mt5Config = pgTable("mt5_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  host: varchar("host", { length: 255 }).notNull(),
  port: integer("port").notNull(),
  accountId: varchar("account_id", { length: 100 }),
  lotSize: decimal("lot_size", { precision: 10, scale: 2 }).notNull().default('0.01'),
  autoTradeEnabled: boolean("auto_trade_enabled").notNull().default(false),
  maxDailyLoss: decimal("max_daily_loss", { precision: 20, scale: 2 }),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Insert schemas
export const insertSignalSchema = createInsertSchema(signals).omit({
  id: true,
  timestamp: true,
  status: true,
}).extend({
  type: z.enum(['buy', 'sell']),
  symbol: z.string().min(1).max(20),
  entryPrice: z.string().or(z.number()),
  stopLoss: z.string().or(z.number()).optional(),
  takeProfit: z.string().or(z.number()).optional(),
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  executionTime: true,
});

export const insertMt5ConfigSchema = createInsertSchema(mt5Config).omit({
  id: true,
  updatedAt: true,
}).extend({
  host: z.string().min(1),
  port: z.coerce.number().min(1).max(65535),
  lotSize: z.union([z.string(), z.number()]),
  maxDailyLoss: z.union([z.string(), z.number()]).optional(),
  autoTradeEnabled: z.boolean(),
});

// Types
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Signal = typeof signals.$inferSelect;

export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Trade = typeof trades.$inferSelect;

export type InsertMt5Config = z.infer<typeof insertMt5ConfigSchema>;
export type Mt5Config = typeof mt5Config.$inferSelect;

// WebSocket message types
export type WSMessage = 
  | { type: 'signal'; data: Signal }
  | { type: 'trade'; data: Trade }
  | { type: 'status'; data: { mt5Connected: boolean; lastPing: string } }
  | { type: 'error'; data: { message: string } };
