import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Trade, Signal } from "@shared/schema";
import { format } from "date-fns";

interface TradeWithSignal extends Trade {
  signal?: Signal;
}

interface TradeHistoryTableProps {
  trades: TradeWithSignal[];
}

export function TradeHistoryTable({ trades }: TradeHistoryTableProps) {
  if (trades.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center" data-testid="empty-trades">
        <p className="text-muted-foreground">No trades executed yet</p>
        <p className="text-sm text-muted-foreground mt-1">Trades will appear here once signals are executed</p>
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="font-semibold">Time</TableHead>
            <TableHead className="font-semibold">Symbol</TableHead>
            <TableHead className="font-semibold">Type</TableHead>
            <TableHead className="font-semibold">Entry</TableHead>
            <TableHead className="font-semibold">SL</TableHead>
            <TableHead className="font-semibold">TP</TableHead>
            <TableHead className="font-semibold">P/L</TableHead>
            <TableHead className="font-semibold">Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {trades.map((trade) => {
            const signal = trade.signal;
            const profitLoss = trade.profitLoss ? parseFloat(trade.profitLoss) : null;
            
            return (
              <TableRow key={trade.id} data-testid={`row-trade-${trade.id}`}>
                <TableCell className="font-mono text-sm" data-testid={`cell-time-${trade.id}`}>
                  {format(new Date(trade.executionTime), 'HH:mm:ss')}
                </TableCell>
                <TableCell className="font-mono font-medium" data-testid={`cell-symbol-${trade.id}`}>
                  {signal?.symbol || '-'}
                </TableCell>
                <TableCell data-testid={`cell-type-${trade.id}`}>
                  <Badge variant={signal?.type === 'buy' ? 'default' : 'destructive'} className="font-mono">
                    {signal?.type?.toUpperCase() || '-'}
                  </Badge>
                </TableCell>
                <TableCell className="font-mono text-sm" data-testid={`cell-entry-${trade.id}`}>
                  {signal?.entryPrice ? parseFloat(signal.entryPrice).toFixed(5) : '-'}
                </TableCell>
                <TableCell className="font-mono text-sm text-destructive" data-testid={`cell-sl-${trade.id}`}>
                  {signal?.stopLoss ? parseFloat(signal.stopLoss).toFixed(5) : '-'}
                </TableCell>
                <TableCell className="font-mono text-sm text-success" data-testid={`cell-tp-${trade.id}`}>
                  {signal?.takeProfit ? parseFloat(signal.takeProfit).toFixed(5) : '-'}
                </TableCell>
                <TableCell className="font-mono font-semibold" data-testid={`cell-pl-${trade.id}`}>
                  {profitLoss !== null ? (
                    <span className={profitLoss >= 0 ? 'text-success' : 'text-destructive'}>
                      {profitLoss >= 0 ? '+' : ''}{profitLoss.toFixed(2)}
                    </span>
                  ) : (
                    '-'
                  )}
                </TableCell>
                <TableCell data-testid={`cell-status-${trade.id}`}>
                  <Badge 
                    variant={trade.status === 'open' ? 'default' : trade.status === 'closed' ? 'secondary' : 'destructive'}
                  >
                    {trade.status}
                  </Badge>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
