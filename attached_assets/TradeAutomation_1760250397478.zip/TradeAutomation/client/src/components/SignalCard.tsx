import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUp, ArrowDown, Clock } from "lucide-react";
import { Signal } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface SignalCardProps {
  signal: Signal;
}

export function SignalCard({ signal }: SignalCardProps) {
  const isBuy = signal.type === 'buy';
  const statusColor = {
    pending: 'bg-warning',
    sent: 'bg-accent',
    executed: 'bg-success',
    failed: 'bg-destructive'
  }[signal.status] || 'bg-muted';

  return (
    <Card 
      className={`border-l-4 ${isBuy ? 'border-l-success' : 'border-l-destructive'}`}
      data-testid={`card-signal-${signal.id}`}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            {isBuy ? (
              <ArrowUp className="h-5 w-5 text-success" data-testid="icon-signal-buy" />
            ) : (
              <ArrowDown className="h-5 w-5 text-destructive" data-testid="icon-signal-sell" />
            )}
            <div>
              <h3 className="font-semibold text-lg" data-testid={`text-signal-type-${signal.id}`}>
                {isBuy ? 'BUY' : 'SELL'} Signal
              </h3>
              <p className="text-sm text-muted-foreground font-mono" data-testid={`text-signal-symbol-${signal.id}`}>
                {signal.symbol}
              </p>
            </div>
          </div>
          <Badge className={statusColor} data-testid={`badge-signal-status-${signal.id}`}>
            {signal.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Entry</p>
            <p className="font-mono font-semibold text-lg" data-testid={`text-entry-${signal.id}`}>
              {parseFloat(signal.entryPrice).toFixed(5)}
            </p>
          </div>
          {signal.stopLoss && (
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Stop Loss</p>
              <p className="font-mono text-sm text-destructive" data-testid={`text-sl-${signal.id}`}>
                {parseFloat(signal.stopLoss).toFixed(5)}
              </p>
            </div>
          )}
          {signal.takeProfit && (
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Take Profit</p>
              <p className="font-mono text-sm text-success" data-testid={`text-tp-${signal.id}`}>
                {parseFloat(signal.takeProfit).toFixed(5)}
              </p>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t">
          <Clock className="h-3 w-3" />
          <span data-testid={`text-timestamp-${signal.id}`}>
            {formatDistanceToNow(new Date(signal.timestamp), { addSuffix: true })}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
