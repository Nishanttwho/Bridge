import { Badge } from "@/components/ui/badge";
import { Activity } from "lucide-react";

interface ConnectionStatusProps {
  mt5Connected: boolean;
  lastPing?: string;
}

export function ConnectionStatus({ mt5Connected, lastPing }: ConnectionStatusProps) {
  return (
    <div className="flex items-center gap-3">
      <Badge 
        variant="outline" 
        className="gap-2 px-3 py-1.5 font-mono text-sm"
        data-testid="badge-mt5-status"
      >
        <div className={`relative flex h-2 w-2 ${mt5Connected ? 'animate-pulse' : ''}`}>
          <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${mt5Connected ? 'bg-status-online' : 'bg-status-offline'}`}></span>
          <span className={`relative inline-flex rounded-full h-2 w-2 ${mt5Connected ? 'bg-status-online' : 'bg-status-offline'}`}></span>
        </div>
        <span className={mt5Connected ? 'text-status-online' : 'text-status-offline'}>
          {mt5Connected ? 'MT5 Connected' : 'Disconnected'}
        </span>
      </Badge>
      {lastPing && (
        <Badge variant="outline" className="gap-2 px-3 py-1.5 font-mono text-sm" data-testid="badge-last-ping">
          <Activity className="h-3 w-3" />
          <span className="text-muted-foreground">Last: {new Date(lastPing).toLocaleTimeString()}</span>
        </Badge>
      )}
    </div>
  );
}
