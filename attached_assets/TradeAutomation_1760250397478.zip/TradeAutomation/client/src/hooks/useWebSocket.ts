import { useEffect, useRef, useCallback } from 'react';
import { WSMessage } from '@shared/schema';
import { queryClient } from '@/lib/queryClient';

export function useWebSocket(onMessage?: (message: WSMessage) => void) {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log('WebSocket connected');
    };

    socket.onmessage = (event) => {
      try {
        const message: WSMessage = JSON.parse(event.data);
        
        // Invalidate queries based on message type
        if (message.type === 'signal') {
          queryClient.invalidateQueries({ queryKey: ['/api/signals'] });
        } else if (message.type === 'trade') {
          queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
        } else if (message.type === 'status') {
          queryClient.invalidateQueries({ queryKey: ['/api/status'] });
        }

        // Call custom message handler if provided
        if (onMessage) {
          onMessage(message);
        }
      } catch (error) {
        console.error('WebSocket message parse error:', error);
      }
    };

    socket.onclose = () => {
      console.log('WebSocket disconnected, reconnecting...');
      reconnectTimeoutRef.current = setTimeout(connect, 3000);
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      socket.close();
    };

    wsRef.current = socket;
  }, [onMessage]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  return wsRef.current;
}
