import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Mt5Config, insertMt5ConfigSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Copy, Check } from "lucide-react";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Settings() {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  
  const { data: config, isLoading } = useQuery<Mt5Config>({
    queryKey: ['/api/config'],
  });

  const form = useForm({
    resolver: zodResolver(insertMt5ConfigSchema),
    defaultValues: {
      host: config?.host || 'localhost',
      port: config?.port || 8080,
      accountId: config?.accountId || '',
      lotSize: config?.lotSize || '0.01',
      autoTradeEnabled: config?.autoTradeEnabled || false,
      maxDailyLoss: config?.maxDailyLoss || '',
    },
    values: config ? {
      host: config.host,
      port: config.port,
      accountId: config.accountId || '',
      lotSize: config.lotSize,
      autoTradeEnabled: config.autoTradeEnabled,
      maxDailyLoss: config.maxDailyLoss || '',
    } : undefined,
  });

  const updateConfig = useMutation({
    mutationFn: (data: any) => apiRequest('POST', '/api/config', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/config'] });
      toast({
        title: "Settings saved",
        description: "MT5 configuration has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    updateConfig.mutate(data);
  };

  const webhookUrl = `${window.location.origin}/api/webhook`;

  const copyWebhookUrl = () => {
    navigator.clipboard.writeText(webhookUrl);
    setCopied(true);
    toast({
      title: "Copied!",
      description: "Webhook URL copied to clipboard",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-settings">Settings</h1>
        <p className="text-muted-foreground mt-1">Configure MT5 connection and trading parameters</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Webhook Configuration</CardTitle>
            <CardDescription>
              Use this URL in your TradingView alert webhook
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input 
                value={webhookUrl} 
                readOnly 
                className="font-mono text-sm"
                data-testid="input-webhook-url"
              />
              <Button 
                variant="outline" 
                size="icon" 
                onClick={copyWebhookUrl}
                data-testid="button-copy-webhook"
              >
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
            <div className="rounded-md bg-muted p-4">
              <p className="text-sm font-medium mb-2">TradingView Alert Setup:</p>
              <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                <li>Open your indicator alert settings</li>
                <li>Select "Webhook URL" notification method</li>
                <li>Paste the URL above</li>
                <li>Set alert message format (see documentation)</li>
              </ol>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>MT5 Connection Status</CardTitle>
            <CardDescription>
              Current connection to MetaTrader 5
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Connection Status</span>
              <Badge variant="outline" className="gap-2">
                <div className="h-2 w-2 rounded-full bg-status-offline"></div>
                <span>Not Connected</span>
              </Badge>
            </div>
            <div className="rounded-md bg-muted p-4">
              <p className="text-sm font-medium mb-2">MT5 EA Installation:</p>
              <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                <li>Download the MT5 Expert Advisor</li>
                <li>Copy to MT5 Experts folder</li>
                <li>Restart MT5 and attach EA to chart</li>
                <li>Configure host and port below</li>
              </ol>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>MT5 Configuration</CardTitle>
          <CardDescription>
            Configure connection settings and trading parameters
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="host"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Host</FormLabel>
                        <FormControl>
                          <Input placeholder="localhost" {...field} data-testid="input-host" />
                        </FormControl>
                        <FormDescription>
                          MT5 server hostname or IP address
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="port"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Port</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            {...field} 
                            onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value, 10) : 0)}
                            data-testid="input-port"
                          />
                        </FormControl>
                        <FormDescription>
                          Port number for MT5 connection
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="accountId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Account ID (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="12345678" {...field} data-testid="input-account-id" />
                        </FormControl>
                        <FormDescription>
                          Your MT5 account number
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="lotSize"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lot Size</FormLabel>
                        <FormControl>
                          <Input placeholder="0.01" {...field} data-testid="input-lot-size" />
                        </FormControl>
                        <FormDescription>
                          Default position size for trades
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="maxDailyLoss"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Max Daily Loss (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="100.00" {...field} data-testid="input-max-loss" />
                        </FormControl>
                        <FormDescription>
                          Stop trading if daily loss exceeds this amount
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="autoTradeEnabled"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">
                          Enable Auto-Trading
                        </FormLabel>
                        <FormDescription>
                          Automatically execute trades when signals are received
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-auto-trade"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={updateConfig.isPending}
                  data-testid="button-save-settings"
                >
                  {updateConfig.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Settings
                </Button>
              </form>
            </Form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
