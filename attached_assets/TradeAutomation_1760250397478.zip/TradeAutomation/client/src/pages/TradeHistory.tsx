import { useQuery } from "@tanstack/react-query";
import { TradeHistoryTable } from "@/components/TradeHistoryTable";
import { Trade, Signal } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface TradeWithSignal extends Trade {
  signal?: Signal;
}

export default function TradeHistory() {
  const { data: trades, isLoading } = useQuery<TradeWithSignal[]>({
    queryKey: ['/api/trades'],
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-trade-history">Trade History</h1>
        <p className="text-muted-foreground mt-1">View all executed trades in MT5</p>
      </div>

      {isLoading ? (
        <Skeleton className="h-96 w-full" />
      ) : (
        <TradeHistoryTable trades={trades || []} />
      )}
    </div>
  );
}
