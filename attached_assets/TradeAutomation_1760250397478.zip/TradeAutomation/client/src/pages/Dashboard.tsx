import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ConnectionStatus } from "@/components/ConnectionStatus";
import { SignalCard } from "@/components/SignalCard";
import { Signal } from "@shared/schema";
import { Activity, TrendingUp, AlertCircle, DollarSign } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: signals, isLoading: signalsLoading } = useQuery<Signal[]>({
    queryKey: ['/api/signals'],
  });

  const { data: status } = useQuery<{ mt5Connected: boolean; lastPing: string }>({
    queryKey: ['/api/status'],
    refetchInterval: 5000,
  });

  const recentSignals = signals?.slice(0, 3) || [];
  const pendingCount = signals?.filter(s => s.status === 'pending').length || 0;
  const executedCount = signals?.filter(s => s.status === 'executed').length || 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-dashboard">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Monitor your automated trading activity</p>
        </div>
        <ConnectionStatus 
          mt5Connected={status?.mt5Connected || false} 
          lastPing={status?.lastPing}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Signals</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono" data-testid="stat-total-signals">
              {signalsLoading ? <Skeleton className="h-8 w-16" /> : signals?.length || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Received from TradingView
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <AlertCircle className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono" data-testid="stat-pending-signals">
              {signalsLoading ? <Skeleton className="h-8 w-16" /> : pendingCount}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Awaiting execution
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Executed</CardTitle>
            <TrendingUp className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono" data-testid="stat-executed-signals">
              {signalsLoading ? <Skeleton className="h-8 w-16" /> : executedCount}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Successfully traded
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono" data-testid="stat-success-rate">
              {signalsLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : signals && signals.length > 0 ? (
                `${Math.round((executedCount / signals.length) * 100)}%`
              ) : (
                '0%'
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Execution success
            </p>
          </CardContent>
        </Card>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Recent Signals</h2>
        {signalsLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
        ) : recentSignals.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {recentSignals.map((signal) => (
              <SignalCard key={signal.id} signal={signal} />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Activity className="h-12 w-12 text-muted-foreground mb-4" />
              <CardTitle className="text-lg mb-2">No signals received</CardTitle>
              <CardDescription className="text-center max-w-sm">
                Configure your TradingView indicator to send webhook alerts to start receiving signals
              </CardDescription>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
