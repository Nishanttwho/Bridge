import { useQuery } from "@tanstack/react-query";
import { SignalCard } from "@/components/SignalCard";
import { Signal } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card";
import { Activity } from "lucide-react";

export default function Signals() {
  const { data: signals, isLoading } = useQuery<Signal[]>({
    queryKey: ['/api/signals'],
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-signals">Signal History</h1>
        <p className="text-muted-foreground mt-1">All signals received from TradingView</p>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      ) : signals && signals.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {signals.map((signal) => (
            <SignalCard key={signal.id} signal={signal} />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Activity className="h-16 w-16 text-muted-foreground mb-4" />
            <CardTitle className="text-xl mb-2">No signals yet</CardTitle>
            <CardDescription className="text-center max-w-md">
              Signals from your TradingView indicator will appear here. Make sure your webhook is configured correctly.
            </CardDescription>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
