import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertSignalSchema, insertMt5ConfigSchema, type WSMessage } from "@shared/schema";
import { z } from "zod";

// WebSocket clients
const wsClients = new Set<WebSocket>();

// Broadcast to all connected clients
function broadcast(message: WSMessage) {
  const data = JSON.stringify(message);
  wsClients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    wsClients.add(ws);

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      wsClients.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      wsClients.delete(ws);
    });

    // Send initial status
    ws.send(JSON.stringify({
      type: 'status',
      data: { mt5Connected: false, lastPing: new Date().toISOString() }
    }));
  });

  // Webhook endpoint - receives TradingView alerts
  app.post('/api/webhook', async (req, res) => {
    try {
      const payload = req.body;
      console.log('Received webhook:', payload);

      // Parse and validate signal
      const signalData = insertSignalSchema.parse({
        type: payload.type,
        symbol: payload.symbol,
        entryPrice: payload.entryPrice,
        stopLoss: payload.stopLoss,
        takeProfit: payload.takeProfit,
        rawPayload: JSON.stringify(payload),
      });

      // Create signal
      const signal = await storage.createSignal(signalData);

      // Broadcast to WebSocket clients
      broadcast({ type: 'signal', data: signal });

      // Check if auto-trade is enabled
      const config = await storage.getConfig();
      if (config?.autoTradeEnabled) {
        // Simulate sending to MT5 (update status)
        await storage.updateSignalStatus(signal.id, 'sent');
        
        // Create a trade record
        const trade = await storage.createTrade({
          signalId: signal.id,
          status: 'open',
          mt5OrderId: `MT5_${Date.now()}`,
          profitLoss: null,
          closeTime: null,
        });

        // Update signal to executed
        await storage.updateSignalStatus(signal.id, 'executed');

        // Broadcast trade creation
        broadcast({ type: 'trade', data: trade });
      }

      res.json({ success: true, signal });
    } catch (error) {
      console.error('Webhook error:', error);
      res.status(400).json({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Invalid webhook payload' 
      });
    }
  });

  // Get all signals
  app.get('/api/signals', async (req, res) => {
    try {
      const signals = await storage.getSignals();
      res.json(signals);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch signals' });
    }
  });

  // Get all trades with signal data
  app.get('/api/trades', async (req, res) => {
    try {
      const trades = await storage.getTrades();
      const tradesWithSignals = await Promise.all(
        trades.map(async (trade) => {
          const signal = trade.signalId ? await storage.getSignal(trade.signalId) : undefined;
          return { ...trade, signal };
        })
      );
      res.json(tradesWithSignals);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch trades' });
    }
  });

  // Get MT5 configuration
  app.get('/api/config', async (req, res) => {
    try {
      const config = await storage.getConfig();
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch config' });
    }
  });

  // Update MT5 configuration
  app.post('/api/config', async (req, res) => {
    try {
      const configData = insertMt5ConfigSchema.parse(req.body);
      const config = await storage.updateConfig(configData);
      res.json(config);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Invalid configuration' 
      });
    }
  });

  // Get system status
  app.get('/api/status', async (req, res) => {
    try {
      res.json({
        mt5Connected: false, // Simulated - would check actual MT5 connection
        lastPing: new Date().toISOString(),
        activeClients: wsClients.size,
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch status' });
    }
  });

  // Manual close trade
  app.post('/api/trades/:id/close', async (req, res) => {
    try {
      const { id } = req.params;
      const { profitLoss } = req.body;

      const trade = await storage.updateTrade(id, {
        status: 'closed',
        profitLoss: profitLoss?.toString() || '0',
        closeTime: new Date(),
      });

      if (trade) {
        broadcast({ type: 'trade', data: trade });
        res.json(trade);
      } else {
        res.status(404).json({ error: 'Trade not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to close trade' });
    }
  });

  // Emergency stop - close all open trades
  app.post('/api/emergency-stop', async (req, res) => {
    try {
      const trades = await storage.getTrades();
      const openTrades = trades.filter(t => t.status === 'open');

      for (const trade of openTrades) {
        await storage.updateTrade(trade.id, {
          status: 'closed',
          closeTime: new Date(),
          profitLoss: '0',
        });
      }

      // Disable auto-trading
      const config = await storage.getConfig();
      if (config) {
        await storage.updateConfig({
          ...config,
          autoTradeEnabled: false,
        });
      }

      res.json({ success: true, closedTrades: openTrades.length });
    } catch (error) {
      res.status(500).json({ error: 'Emergency stop failed' });
    }
  });

  return httpServer;
}
