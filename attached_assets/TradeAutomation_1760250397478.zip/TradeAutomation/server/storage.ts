import { 
  type Signal, type InsertSignal, 
  type Trade, type InsertTrade,
  type Mt5Config, type InsertMt5Config 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Signals
  getSignals(): Promise<Signal[]>;
  getSignal(id: string): Promise<Signal | undefined>;
  createSignal(signal: InsertSignal): Promise<Signal>;
  updateSignalStatus(id: string, status: string): Promise<Signal | undefined>;
  
  // Trades
  getTrades(): Promise<Trade[]>;
  getTrade(id: string): Promise<Trade | undefined>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined>;
  
  // MT5 Config
  getConfig(): Promise<Mt5Config | undefined>;
  updateConfig(config: InsertMt5Config): Promise<Mt5Config>;
}

export class MemStorage implements IStorage {
  private signals: Map<string, Signal>;
  private trades: Map<string, Trade>;
  private config: Mt5Config | undefined;

  constructor() {
    this.signals = new Map();
    this.trades = new Map();
    this.config = {
      id: randomUUID(),
      host: 'localhost',
      port: 8080,
      accountId: null,
      lotSize: '0.01',
      autoTradeEnabled: false,
      maxDailyLoss: null,
      updatedAt: new Date(),
    };
  }

  // Signals
  async getSignals(): Promise<Signal[]> {
    return Array.from(this.signals.values()).sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  async getSignal(id: string): Promise<Signal | undefined> {
    return this.signals.get(id);
  }

  async createSignal(insertSignal: InsertSignal): Promise<Signal> {
    const signal: Signal = {
      id: randomUUID(),
      timestamp: new Date(),
      status: 'pending',
      type: insertSignal.type,
      symbol: insertSignal.symbol,
      entryPrice: insertSignal.entryPrice.toString(),
      stopLoss: insertSignal.stopLoss?.toString() || null,
      takeProfit: insertSignal.takeProfit?.toString() || null,
      rawPayload: insertSignal.rawPayload || null,
    };
    this.signals.set(signal.id, signal);
    return signal;
  }

  async updateSignalStatus(id: string, status: string): Promise<Signal | undefined> {
    const signal = this.signals.get(id);
    if (!signal) return undefined;
    
    signal.status = status;
    this.signals.set(id, signal);
    return signal;
  }

  // Trades
  async getTrades(): Promise<Trade[]> {
    return Array.from(this.trades.values()).sort((a, b) => 
      new Date(b.executionTime).getTime() - new Date(a.executionTime).getTime()
    );
  }

  async getTrade(id: string): Promise<Trade | undefined> {
    return this.trades.get(id);
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const trade: Trade = {
      id: randomUUID(),
      executionTime: new Date(),
      signalId: insertTrade.signalId || null,
      status: insertTrade.status,
      mt5OrderId: insertTrade.mt5OrderId || null,
      profitLoss: insertTrade.profitLoss || null,
      closeTime: insertTrade.closeTime || null,
    };
    this.trades.set(trade.id, trade);
    return trade;
  }

  async updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined> {
    const trade = this.trades.get(id);
    if (!trade) return undefined;
    
    const updatedTrade = { ...trade, ...updates };
    this.trades.set(id, updatedTrade);
    return updatedTrade;
  }

  // MT5 Config
  async getConfig(): Promise<Mt5Config | undefined> {
    return this.config;
  }

  async updateConfig(insertConfig: InsertMt5Config): Promise<Mt5Config> {
    this.config = {
      id: this.config?.id || randomUUID(),
      host: insertConfig.host,
      port: insertConfig.port,
      accountId: insertConfig.accountId || null,
      lotSize: insertConfig.lotSize.toString(),
      autoTradeEnabled: insertConfig.autoTradeEnabled,
      maxDailyLoss: insertConfig.maxDailyLoss?.toString() || null,
      updatedAt: new Date(),
    };
    return this.config;
  }
}

export const storage = new MemStorage();
