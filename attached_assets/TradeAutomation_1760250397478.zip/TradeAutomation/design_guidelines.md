# Trading Bridge Dashboard - Design Guidelines

## Design Approach
**Selected Approach:** Design System with Trading Platform Inspiration
- **Primary Reference:** TradingView's clean data-focused interface + Interactive Brokers' reliability aesthetic
- **Core Principle:** Trust through clarity - every pixel serves the trader's decision-making process
- **Key Insight:** Trading applications prioritize information hierarchy, real-time status visibility, and zero ambiguity

## Color Palette

### Dark Mode (Primary)
- **Background Primary:** 15 8% 12% (deep charcoal, almost black)
- **Background Secondary:** 220 10% 18% (slightly lighter panels)
- **Background Tertiary:** 220 8% 22% (elevated cards/modals)
- **Border/Divider:** 220 10% 28% (subtle separation)

### Semantic Colors
- **Success/Long:** 142 76% 45% (trading green, not too bright)
- **Danger/Short:** 0 84% 58% (alert red)
- **Warning:** 38 92% 50% (amber for caution states)
- **Info/Neutral:** 217 91% 60% (blue for informational states)
- **Accent:** 142 76% 45% (same as success for consistency)

### Text Colors
- **Primary Text:** 0 0% 95% (near white)
- **Secondary Text:** 0 0% 70% (muted descriptions)
- **Tertiary/Disabled:** 0 0% 50% (placeholder text)

## Typography

**Font Stack:**
- Primary: 'Inter', system-ui, -apple-system, sans-serif
- Monospace (for prices/data): 'JetBrains Mono', 'Fira Code', monospace

**Scale:**
- Headings: font-semibold, tracking-tight
- Body: font-normal, leading-relaxed
- Data/Numbers: font-mono, tabular-nums (for alignment)
- Labels: font-medium, text-sm, uppercase tracking-wide

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16
- Tight spacing: p-2, gap-2 (within components)
- Standard spacing: p-4, gap-4 (between related elements)
- Section spacing: p-6, p-8 (major sections)
- Page margins: p-12, p-16 (outer containers)

**Grid Structure:**
- Main container: max-w-7xl mx-auto
- Dashboard grid: 3-column on desktop (sidebar 280px + main + status panel 320px)
- Responsive: Stack to single column on mobile

## Component Library

### Navigation
- **Top Bar:** Fixed header with app logo, connection status pills, user settings
- **Sidebar:** Collapsible left panel with navigation icons + labels
- Sections: Dashboard, Signals, Trade History, Configuration, Logs

### Status Indicators
- **Connection Pills:** Rounded badges with dot indicator + status text
  - Green dot: "MT5 Connected"
  - Red dot: "Disconnected" 
  - Amber dot: "Connecting..."
- **Real-time Pulse:** Subtle green pulse animation on active connections

### Data Display Cards
- **Signal Card:** Elevated card with border-l-4 accent color (green for buy, red for sell)
  - Header: Signal type + timestamp
  - Body: Entry price (large mono font), SL/TP (smaller, aligned)
  - Footer: Execution status badge
- **Trade Log Table:** Alternating row backgrounds, sticky header
  - Columns: Time, Pair, Direction, Entry, SL, TP, P/L, Status
  - Highlight active trades with subtle border

### Forms & Configuration
- **Input Fields:** Dark backgrounds (bg-tertiary) with focus ring in accent color
- **Toggle Switches:** Custom styled for MT5 connection, auto-trade enable
- **Dropdown Selects:** Custom styled with chevron icon, matching dark theme
- **Number Inputs:** Monospace font with increment/decrement buttons

### Action Controls
- **Primary CTA:** Solid button with success green for "Enable Auto-Trade"
- **Danger Action:** Solid red button for "Emergency Stop All"
- **Secondary Actions:** Outline buttons with border matching text color
- **Icon Buttons:** Ghost style for utility actions (refresh, settings)

### Real-time Dashboard
- **Webhook Status Panel:** Card showing last signal received, timestamp, payload preview
- **Trade Execution Monitor:** Live feed of trade commands sent to MT5
- **P/L Summary:** Large numbers with color coding, today's stats

### Overlays
- **Modals:** Backdrop blur with centered card, max-w-2xl
- **Alerts/Toasts:** Top-right position, auto-dismiss, color-coded by severity
- **Confirmation Dialogs:** For critical actions (close all trades, disconnect)

## Visual Hierarchy

1. **Critical Status:** Connection indicators and emergency controls - always visible
2. **Primary Data:** Active signals and open trades - prominent cards
3. **Secondary Info:** Historical data and logs - accessible tables
4. **Tertiary:** Configuration and settings - dedicated panel

## Animations

**Minimal, Purposeful Motion:**
- Connection status: Gentle pulse on active (1.5s duration, subtle opacity)
- New signal: Brief border flash (200ms)
- Trade execution: Slide-in notification (300ms ease-out)
- **No:** Complex animations, parallax, or decorative motion

## Images

**No hero images needed** - This is a utility dashboard
- **Icons Only:** Use Heroicons for navigation and status indicators
- **Trading Pair Icons:** If available, small circular icons for currency pairs
- **Placeholder States:** Illustrative empty states (e.g., "No active trades" with icon)

## Accessibility & Dark Mode

- **Contrast:** All text meets WCAG AA standards against dark backgrounds
- **Focus States:** Clear focus rings (2px accent color) on all interactive elements
- **Status Communication:** Never rely on color alone - use text + icons
- **Keyboard Navigation:** Full keyboard support with visible focus indicators
- **Screen Readers:** Proper ARIA labels for status indicators and real-time updates