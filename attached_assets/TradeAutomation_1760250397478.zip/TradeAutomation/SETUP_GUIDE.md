# Trading Bridge - Complete Setup Guide

## 🎯 What This Does

This application bridges TradingView indicator signals to MetaTrader 5 for automatic trade execution. When your TradingView indicator generates a buy/sell signal, it sends a webhook to this bridge, which then executes the trade in MT5 with your specified stop-loss and take-profit levels.

## 📋 Prerequisites

1. **TradingView Premium Account** (for webhook alerts)
2. **MetaTrader 5** installed and running
3. **Your Trading Indicator** (the Pine Script file you provided)
4. **Replit Account** (for hosting the bridge - always online)

## 🚀 Part 1: Bridge Application Setup

### Step 1: Deploy on Replit

1. The application is already running on Replit
2. Copy your Replit URL (e.g., `https://your-app.replit.app`)
3. Go to the Settings page in the dashboard
4. Copy the **Webhook URL** shown (e.g., `https://your-app.replit.app/api/webhook`)

### Step 2: Configure MT5 Settings

1. In the Settings page, configure:
   - **Host**: `localhost` (if MT5 is on same machine) or your MT5 server IP
   - **Port**: `8080` (default)
   - **Lot Size**: Your preferred position size (e.g., `0.01` for micro lots)
   - **Max Daily Loss** (optional): Safety limit to stop trading
   - **Auto-Trade**: Toggle ON to enable automatic execution

2. Click **Save Settings**

## 📊 Part 2: TradingView Indicator Modification

### Step 1: Add SL/TP Calculation to Your Indicator

Add this code to your existing TradingView indicator to calculate stop-loss and take-profit:

```pinescript
//@version=5
// ... your existing indicator code ...

// Add these inputs at the top with your other inputs
atrPeriod = input.int(14, "ATR Period for SL/TP", group="Risk Management")
atrMultiplierSL = input.float(1.5, "ATR Multiplier for Stop Loss", group="Risk Management")
atrMultiplierTP = input.float(3.0, "ATR Multiplier for Take Profit", group="Risk Management")

// Calculate ATR for dynamic SL/TP
atrValue = ta.atr(atrPeriod)

// Modify your existing BUY signal section
if buy  // Your existing buy condition
    entryPrice = close
    stopLoss = entryPrice - (atrValue * atrMultiplierSL)
    takeProfit = entryPrice + (atrValue * atrMultiplierTP)
    
    // Create JSON payload for webhook
    jsonPayload = '{"type":"buy","symbol":"' + syminfo.ticker + '","entryPrice":' + 
                  str.tostring(entryPrice) + ',"stopLoss":' + str.tostring(stopLoss) + 
                  ',"takeProfit":' + str.tostring(takeProfit) + '}'
    
    // Send alert (configure webhook in alert settings)
    alert(jsonPayload, alert.freq_once_per_bar)
    
    // Your existing buy visualization code...
    plotshape(buy, title='Buy', text='Buy', style=shape.labelup, location=location.belowbar, 
              color=color.new(color.green, 0), textcolor=color.new(color.white, 0), size=size.tiny)

// Modify your existing SELL signal section  
if sell  // Your existing sell condition
    entryPrice = close
    stopLoss = entryPrice + (atrValue * atrMultiplierSL)
    takeProfit = entryPrice - (atrValue * atrMultiplierTP)
    
    // Create JSON payload for webhook
    jsonPayload = '{"type":"sell","symbol":"' + syminfo.ticker + '","entryPrice":' + 
                  str.tostring(entryPrice) + ',"stopLoss":' + str.tostring(stopLoss) + 
                  ',"takeProfit":' + str.tostring(takeProfit) + '}'
    
    // Send alert (configure webhook in alert settings)
    alert(jsonPayload, alert.freq_once_per_bar)
    
    // Your existing sell visualization code...
    plotshape(sell, title='Sell', text='Sell', style=shape.labeldown, location=location.abovebar, 
              color=color.new(color.red, 0), textcolor=color.new(color.white, 0), size=size.tiny)
```

### Step 2: Create Webhook Alert in TradingView

1. Open your chart with the modified indicator
2. Click **"Create Alert"** (alarm clock icon)
3. Set:
   - **Condition**: Your indicator > Any alert() function call
   - **Alert Name**: "Trading Bridge Signal"
   - **Message**: `{{strategy.order.alert_message}}` (this will use the JSON from the alert() function)
   - **Webhook URL**: Paste your webhook URL from Step 1
4. Click **"Create"**

### Alternative: Manual Alert Message

If the above doesn't work, you can manually set the message in the alert:

```json
{
  "type": "{{strategy.order.action}}",
  "symbol": "{{ticker}}",
  "entryPrice": {{close}},
  "stopLoss": {{plot_0}},
  "takeProfit": {{plot_1}}
}
```

Note: You'll need to adjust plot_0 and plot_1 to match your indicator's SL/TP plot indices.

## 🖥️ Part 3: MT5 Expert Advisor Setup

### Important: MT5 EA Limitation

The MT5 Expert Advisor (EA) requires custom development because:
- MT5 doesn't natively support external webhook connections
- Requires socket library or HTTP polling implementation
- Needs JSON parsing functionality

### Options:

#### Option A: Hire MQL5 Developer (Recommended)
1. Download `MT5_Expert_Advisor.mq5` from this project
2. Hire developer on:
   - MQL5.com Freelance
   - Fiverr (search "MQL5 EA development")
   - Upwork
3. Provide them with:
   - The `MT5_Expert_Advisor.mq5` template
   - Your bridge URL and port
   - Your risk parameters

**Cost**: $100-$300 typically

#### Option B: Manual Trading (Free)
Use the bridge dashboard to:
1. Monitor incoming signals in real-time
2. Manually execute trades in MT5 based on signals
3. Track performance in the dashboard

The dashboard shows:
- Real-time signals with entry, SL, TP
- Trade history
- Connection status
- Performance metrics

#### Option C: Use Bridge API Directly (Advanced)
If you have programming skills, create a simple script that:
1. Polls `GET /api/signals` endpoint
2. Executes trades via MT5's Python API or other connector
3. Updates trade status via `POST /api/trades/:id/close`

## 🧪 Testing Your Setup

### 1. Test Webhook (No MT5 Required)

1. Use a tool like `curl` or Postman:
```bash
curl -X POST https://your-app.replit.app/api/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "type": "buy",
    "symbol": "XAUUSD",
    "entryPrice": 2650.50,
    "stopLoss": 2645.00,
    "takeProfit": 2660.00
  }'
```

2. Check the dashboard - you should see the signal appear

### 2. Test TradingView Alert

1. Trigger a manual alert from TradingView (right-click chart → "Create Alert")
2. Use "Crossing" condition to trigger immediately
3. Check dashboard for received signal

### 3. Full Integration Test

1. Enable auto-trade in Settings
2. Send test signal via webhook or TradingView
3. Verify signal appears in dashboard
4. Check that trade record is created (even without MT5 connection)

## 📈 Daily Operation

Once everything is set up:

1. **Morning**: 
   - Check dashboard connection status
   - Verify auto-trade is enabled (if desired)
   - Review any overnight signals/trades

2. **During Trading**:
   - Signals automatically sent from TradingView
   - Dashboard shows real-time status
   - Trades execute automatically (if EA is connected)

3. **Evening**:
   - Review trade history
   - Check P/L performance
   - Adjust settings if needed

## ⚠️ Risk Management

**IMPORTANT Safety Features:**

1. **Max Daily Loss**: Set in Settings to auto-disable trading if limit reached
2. **Lot Size**: Keep small initially (0.01) for testing
3. **Emergency Stop**: Use "Emergency Stop" button to close all trades immediately
4. **Manual Override**: Disable auto-trade at any time

**Testing Recommendations:**

1. Start with demo MT5 account
2. Use minimum lot sizes (0.01)
3. Monitor first 10-20 signals manually
4. Only enable auto-trade after validating signal quality

## 🔧 Troubleshooting

### Signals Not Appearing
- Check webhook URL is correct in TradingView alert
- Verify alert is active (green checkmark in TradingView)
- Check dashboard logs for webhook errors

### Trades Not Executing  
- Verify auto-trade is enabled in Settings
- Check MT5 EA is running and connected
- Ensure MT5 allows automated trading (Tools → Options → Expert Advisors)

### Connection Issues
- Verify host and port in Settings
- Check firewall isn't blocking the connection
- Ensure MT5 is running when EA tries to connect

## 📝 Support Files

- `MT5_Expert_Advisor.mq5` - MT5 EA template (requires development)
- `replit.md` - Technical documentation
- This file - Complete setup guide

## 🎓 Next Steps

1. ✅ Deploy bridge on Replit
2. ✅ Modify TradingView indicator with SL/TP
3. ✅ Create webhook alert in TradingView
4. ✅ Test signal reception
5. ⏳ Develop MT5 EA (hire developer or use manual trading)
6. ✅ Test with demo account
7. ✅ Monitor and optimize

---

**Need Help?** Check the dashboard's Settings page for your webhook URL and configuration status.
